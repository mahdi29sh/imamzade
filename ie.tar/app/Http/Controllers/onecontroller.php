<?php

namespace App\Http\Controllers;
//         API controller            //

use App\imamzade;
use Cornford\Googlmapper\Facades\MapperFacade as Mapper;
use App\User;
use App\Province;
use Illuminate\Http\Request;


class onecontroller extends Controller
{
    //******** show api start ****************************************//
    public function show_city ($id)
    {
        return \App\City::find($id);

    }
    public function show_province ($id)
    {
        return \App\Province::find($id);

    }
    public function show_ziaratname ($id)
    {
        return \App\ziaratname::find($id);

    }
    public function show_imamzade ($id)
    {
        $result = \App\imamzade::find($id);
        return $result;

    }
    //******** show api end ****************************************//
    //************** index api start******************************//
    public function index_city()
    {
        $result =  \App\City::all();
        $return = array('city' => $result);
        return $return;
    }
    public function index_province()
    {
        $result = Province::all();
        $return = array('province' => $result);
        return $return;

    }
    public function index_imamzade()
    {
        $result = \Illuminate\Support\Facades\DB::table('imamzades')
            ->join('cities', 'cities.Cid', '=', 'imamzades.CID')
            ->join('provinces', 'provinces.Pid', '=', 'imamzades.PID')->get();
        $return = array('imamzade' => $result);
        return $return;
    }
    public function index_ziaratname()
    {
        return \App\ziaratname::all();
    }
    //************** index api end******************************//
    //************** store api start **************************//
    public function store_imamzade(Request $request)
    {
        $imamzade= \App\imamzade::create($request->all());
        return response()->json($imamzade , 201);
    }
    public function store_ziaratname(Request $request)
    {
        $ziaratname = \App\ziaratname::create($request->all());
        return response()->json($ziaratname , 201);
    }
    //************** store api end **************************//
    //************** update api start ******************************//
    public function update_imamzade(Request $request, $id)
    {
        $imamzade = \App\imamzade::findOrFail($id);
        $imamzade->update($request->all());

        return response()->json($imamzade , 200);
    }
    public function update_ziaratname(Request $request, $id)
    {
        $ziaratname = \App\ziaratname::findOrFail($id);
        $ziaratname->update($request->all());

        return response()->json($ziaratname , 200);
    }
    //************** update api end ******************************//
    //************** delete api start ******************************//
    public function delete_imamzade(Request $request, $id)
    {
        $imamzade = \App\imamzade::findOrFail($id);
        $imamzade->delete();

        return 204;
    }
    public function delete_ziaratname(Request $request, $id)
    {
        $ziaratname = \App\ziaratname::findOrFail($id);
        $ziaratname->delete();

        return 204;
    }


    //************** delete api end ******************************//
    public function index(){

        $mapArrays = imamzade::all();
        return view('map' ,compact('mapArrays'));




    }
    public function search($str){
        $imamzade = imamzade::where('Name' , 'LIKE','%'.$str.'%')->get();
        return view('search',$imamzade);
    }
        
}
