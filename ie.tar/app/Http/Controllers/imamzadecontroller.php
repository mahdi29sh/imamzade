<?php

namespace App\Http\Controllers;

use App\City;
use App\image;
use App\Province;
use App\temp_image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;


use Symfony\Component\HttpFoundation\Session\Session;
use function MongoDB\BSON\toJSON;

class imamzadecontroller extends Controller
{
    public function create(){
        $province = Province::all();
        return view('create')->with('result',[$province,null]);
    }
    public function fileUpload(Request $request,$id) {
        $this->validate($request, [
            'input_img' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        if ($request->hasFile('input_img')) {
            $image = $request->file('input_img');
            $name = time().'.'.$image->getClientOriginalExtension();
            $destinationPath = public_path('/images');
            $image->move($destinationPath, $name);

            $arr['TIID'] = $id;
            $arr['image'] = $name;
            $arr['is_first'] = false;
            $img = temp_image::create($arr);

            return back()->with('success','Image Upload successfully');
        }

    }
    public function store(Request $request)
    {

        $pid = DB::table('Provinces')->where('province_Name', '=', $request['select_province'])->get();

        $cid = DB::table('Cities')->where('city_Name', '=', $request['select_city'])->get();

        $uid = Auth::user();
        $arr['imamzade_Name'] = $request['imamzade_Name'];
        $arr['Ancestor'] = $request['Ancestor'];
        $arr['Address'] = $request['Address'];
        $arr['latitude'] = $request['latitude'];
        $arr['longitude'] = $request['longitude'];
        $arr['PID'] = $pid[0]->Pid;
        $arr['CID'] = $cid[0]->Cid;
        if (Auth::user()) {

            $arr['UID'] = $uid->Uid;
            $imamzade_temp = \App\imamzade_temp::create($arr);
            $this->fileUpload($request ,1);
            return redirect()->route('home');
        }

        else {
            return redirect()->route('login');
        }

    }
    public function creates(){


                $pid = DB::table('Provinces')->where('province_Name','=',$_GET['province'])->get();
                print $pid;

                $city = DB::table('Cities')->where('Province','=',$pid[0]->Pid)->get();
                $u ="";
                foreach ($city as $ci) {
                    $u .= '<option value="'.$ci->city_Name.'">' .$ci->city_Name.'</option>';
                }

                return $u;

    }
}
