<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ziaratname extends Model
{
    //
    protected $primaryKey = 'Zid';
}
